package com.example
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.timetableplanner.Api.RetrofitClient
import com.example.timetableplanner.R
import com.example.timetableplanner.ui.home.ApiResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class create_newlist: AppCompatActivity() {
    private lateinit var userlists:SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_newlist)

        val createlist = findViewById<EditText>(R.id.enterlist)
        val btnSave = findViewById<Button>(R.id.buttonsave)
        userlists=getSharedPreferences("study",0)
        val useremail=userlists.getString("email", null).toString()
        btnSave.setOnClickListener {
            val listText = createlist.text.toString().trim()

            if (listText.isNotEmpty()) {
                sendListToServer(useremail, listText)
            } else {
                Toast.makeText(this, "Please enter a list name", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendListToServer(email: String, list: String) {

        RetrofitClient.instance.createList(email, list).enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful && response.body()?.status == true) {
                    Toast.makeText(applicationContext, "List Created Successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(applicationContext, "Failed to create list", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Toast.makeText(applicationContext, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
