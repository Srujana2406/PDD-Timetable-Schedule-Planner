package com.example.timetableplanner

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Profile : AppCompatActivity() {
    lateinit var getstartButton: AppCompatButton
    lateinit var logoutbtn:ImageView
    lateinit var userlists:SharedPreferences
    lateinit var editor:SharedPreferences.Editor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        getstartButton = findViewById(R.id.buttonedit)
        getstartButton.setOnClickListener {
            val intent = Intent(this, Edit_profile::class.java)
            startActivity(intent)
        }
        logoutbtn = findViewById(R.id.logoutimg)
        logoutbtn.setOnClickListener {
            editor.clear().apply()
            finishAffinity()
        }
        userlists=getSharedPreferences("study",0)
        editor=userlists.edit()
    }
}