package com.example.timetableplanner

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.add_notes
import com.example.add_subtasks

class task_actions : AppCompatActivity() {
    lateinit var textview: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_actions)
        textview = findViewById(R.id.markcomplete)
        textview.setOnClickListener {
            val intent = Intent(this, task_completed::class.java)
            startActivity(intent)
        }
        textview = findViewById(R.id.remainders)
        textview.setOnClickListener {
            val intent = Intent(this, add_remainder::class.java)
            startActivity(intent)
        }
        textview = findViewById(R.id.subtasks)
        textview.setOnClickListener {
            val intent = Intent(this, add_subtasks::class.java)
            startActivity(intent)
        }
        textview = findViewById(R.id.addnotes)
        textview.setOnClickListener {
            val intent = Intent(this, add_notes::class.java)
            startActivity(intent)
        }
    }
}