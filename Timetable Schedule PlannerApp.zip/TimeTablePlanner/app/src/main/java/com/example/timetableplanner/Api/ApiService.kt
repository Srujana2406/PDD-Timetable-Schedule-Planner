package com.example.timetableplanner.Api


import com.example.timetableplanner.SignupRequest

import com.example.timetableplanner.SignupResponse
import com.example.timetableplanner.LoginRequest
import com.example.timetableplanner.LoginResponse
import com.example.timetableplanner.ui.home.ApiResponse
import com.example.timetableplanner.ui.home.ListResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    @FormUrlEncoded
    @POST("pdd/create.php")
    fun signupUser(@Field("email") email:String,
                   @Field("username") username:String,
                   @Field("password") password:String): Call<SignupResponse>

    @FormUrlEncoded
    @POST("pdd/createlogin.php")
    fun loginUser(@Field("email") email:String,
                  @Field("password") password:String):  Call<LoginResponse>

    @FormUrlEncoded
    @POST("pdd/createlist.php")
    fun createList(@Field("email") email:String,
                  @Field("list") list:String,):  Call<ApiResponse>

    @GET("pdd/readlist.php")
    fun getLists(): Call<ListResponse>

}
