package com.example.timetableplanner

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class study_notasks : AppCompatActivity() {
    lateinit var getstartButton: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_study_notasks)
        getstartButton = findViewById(R.id.plusbtn)
        getstartButton.setOnClickListener {
            val intent = Intent(this, Assign_task::class.java)
            startActivity(intent)
        }
    }
}