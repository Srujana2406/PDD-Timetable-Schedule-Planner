package com.example.timetableplanner

data class SignupRequest(
    val email: String,
    val username: String,
    val password: String
)

data class SignupResponse(
    val status: Boolean,
    val message: String,
    val data: UserData?
)

data class UserData(
    val id: String,
    val email: String,
    val username: String
)

