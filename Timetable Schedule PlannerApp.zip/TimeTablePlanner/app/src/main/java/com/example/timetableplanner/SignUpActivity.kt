package com.example.timetableplanner

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.timetableplanner.Api.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SignUpActivity : AppCompatActivity() {
    private lateinit var emailEditText: EditText
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var signupButton: Button
    private lateinit var logintext: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        emailEditText = findViewById(R.id.edtEmail)
        usernameEditText = findViewById(R.id.edtUname)
        passwordEditText = findViewById(R.id.edtPass)
        signupButton = findViewById(R.id.buttonsignup)
        logintext=findViewById(R.id.logintext)
        logintext.setOnClickListener {
            val intent=Intent(this,Log_in::class.java)
            startActivity(intent)
        }

        signupButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isEmpty() || username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                signupUser(email, username, password)
            }
        }
    }

    private fun signupUser(email: String, username: String, password: String) {
        val call = RetrofitClient.instance.signupUser(email, username, password)

        call.enqueue(object : Callback<SignupResponse> {
            override fun onResponse(call: Call<SignupResponse>, response: Response<SignupResponse>) {
                if (response.isSuccessful) {
                    val signupResponse = response.body()
                    if (signupResponse?.status == true) {
                        Toast.makeText(this@SignUpActivity, signupResponse.message, Toast.LENGTH_LONG).show()
                        startActivity(Intent(this@SignUpActivity, Log_in::class.java))
                        finish()
                    } else {
                        Toast.makeText(this@SignUpActivity, "Signup failed: ${signupResponse?.message}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this@SignUpActivity, "Error: ${response.errorBody()?.string()}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<SignupResponse>, t: Throwable) {
                Log.e("API_ERROR", "Signup Failed", t)
                Toast.makeText(this@SignUpActivity, "Signup failed: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })

    }
}
