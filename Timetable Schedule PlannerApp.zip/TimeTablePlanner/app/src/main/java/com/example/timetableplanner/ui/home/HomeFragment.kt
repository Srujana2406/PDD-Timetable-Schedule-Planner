package com.example.timetableplanner.ui.home

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.create_newlist
import com.example.timetableplanner.Api.RetrofitClient
import com.example.timetableplanner.Profile
import com.example.timetableplanner.R
import com.example.timetableplanner.study_notasks
import retrofit2.Call
import okhttp3.Callback
import retrofit2.Response

class HomeFragment : Fragment() {
    private lateinit var profile: ImageView
    private lateinit var lists: TextView
    private lateinit var addlist: TextView
    private lateinit var list:RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.fragment_home, container, false)
        profile=v.findViewById<ImageView>(R.id.profile)
        list=v.findViewById<RecyclerView>(R.id.showlists)
        profile.setOnClickListener {
            val intent=Intent(requireContext(),Profile::class.java)
            startActivity(intent)
        }
        addlist=v.findViewById<TextView>(R.id.addlist)
        addlist.setOnClickListener {
            val intent=Intent(requireContext(), create_newlist::class.java)
            startActivity(intent)
        }
        fetchLists()
        return v
    }
    fun fetchLists() {
        val call = RetrofitClient.instance.getLists()

        call.enqueue(object : retrofit2.Callback<ListResponse>{
            override fun onResponse(call: Call<ListResponse>, response: Response<ListResponse>) {
                if (response.isSuccessful) {
                    val listResponse = response.body()
                    if (listResponse != null) {
                        list.layoutManager=LinearLayoutManager(requireContext())
                        list.adapter=HomeAdapter(requireContext(),response.body()!!.data)
                    } else {
                        println("Response is empty")
                    }
                } else {
                    println("Failed to retrieve lists: ${response.errorBody()?.string()}")
                }
            }
            override fun onFailure(call: Call<ListResponse>, t: Throwable) {
                println("Error: ${t.message}")
            }
        })
    }
}