package com.example.timetableplanner

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class display_tasks : AppCompatActivity() {
    lateinit var taskname: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_tasks)
        taskname = findViewById(R.id.task)
        taskname.setOnClickListener {
            val intent = Intent(this, task_actions::class.java)
            startActivity(intent)
        }
    }
}