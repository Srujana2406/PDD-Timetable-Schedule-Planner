package com.example.timetableplanner


import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Login_Signup : AppCompatActivity() {
    lateinit var signupButton: AppCompatButton
    lateinit var loginButton: AppCompatButton


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_signup)

        signupButton = findViewById(R.id.buttonsignup)
        signupButton.setOnClickListener {
            val intent = Intent(this,SignUpActivity::class.java)
            startActivity(intent)
        }
        loginButton = findViewById(R.id.buttonlogin)
        loginButton.setOnClickListener {
            val intent = Intent(this,Log_in::class.java)
            startActivity(intent)
        }
    }
}