package com.example.timetableplanner.ui.home

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.timetableplanner.R
import com.example.timetableplanner.study_notasks

class HomeAdapter(
    private val context: Context,
    private val itemList: List<ListItem>
) : RecyclerView.Adapter<HomeAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = LayoutInflater.from(context).inflate(R.layout.rv_list_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = itemList[position]
        holder.listName.text = item.list

        // Handle item click
        holder.itemView.setOnClickListener {
            val intent = Intent(context,study_notasks::class.java)
            intent.putExtra("STUDY_NAME", item.list) // Pass the study name
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var listName: TextView = itemView.findViewById(R.id.study)
    }
}
