package com.example.timetableplanner

data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val status: Boolean,
    val message: String,
    val users: User?
)

data class User(
    val id: String,
    val email: String,
    val username: String
)
