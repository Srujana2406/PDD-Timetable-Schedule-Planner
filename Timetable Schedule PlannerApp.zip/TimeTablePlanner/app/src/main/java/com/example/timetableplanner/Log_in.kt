package com.example.timetableplanner

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.timetableplanner.Api.RetrofitClient
import com.example.timetableplanner.LoginRequest
import com.example.timetableplanner.LoginResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Log_in : AppCompatActivity() {

    private lateinit var btnLogin: Button
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var creareacc: TextView
    private lateinit var userlists:SharedPreferences
    private lateinit var editor:SharedPreferences.Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)
        userlists=getSharedPreferences("study",0)
        editor=userlists.edit()



        // Initialize views
        btnLogin = findViewById(R.id.btnLogin)
        emailEditText = findViewById(R.id.Email)
        passwordEditText = findViewById(R.id.password)
        creareacc=findViewById(R.id.textView11)
        creareacc.setOnClickListener {
            val intent=Intent(this,SignUpActivity::class.java)
            startActivity(intent)
        }



        btnLogin.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                loginUser(email, password)
            } else {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loginUser(email: String, password: String) {
        val request = LoginRequest(email, password)

        RetrofitClient.instance?.loginUser(email, password)?.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful) {
                    val loginResponse = response.body()
                    if (loginResponse?.status == true) {
                        Toast.makeText(applicationContext, "Login Successful!", Toast.LENGTH_SHORT).show()
                        editor.putString("email",email).apply()
                        val intent = Intent(this@Log_in, UserMainActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(applicationContext, "Login Failed: ${loginResponse?.message}", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(applicationContext, "Error: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                Toast.makeText(applicationContext, "Failed: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
