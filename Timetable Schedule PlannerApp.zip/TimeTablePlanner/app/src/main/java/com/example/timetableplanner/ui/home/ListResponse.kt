package com.example.timetableplanner.ui.home

data class ListResponse(
    val message: String,
    val data: List<ListItem>
)

data class ListItem(
    val id: String,
    val email: String,
    val list: String,
    val created_at: String
)

data class ApiResponse(
    val status: Boolean,
    val message: String,
    val data: ListItem?
)